package com.example.weightapplication

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView

class CalendarAdapter (
    private val daysOfMonth: List<String>,
    private val onItemListener: OnItemListener
) : RecyclerView.Adapter<CalendarViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CalendarViewHolder {
        val inflater = LayoutInflater.from(parent.context)
        val view = inflater.inflate(R.layout.calendar_cell, parent, false)
        val layoutParams = view.layoutParams
        layoutParams.height = (parent.height * 0.16666666).toInt()
        view.layoutParams = layoutParams
        return CalendarViewHolder(view, this)
    }

    override fun onBindViewHolder(holder: CalendarViewHolder, position: Int) {
        holder.dayOfMonth.text = daysOfMonth[position]
        holder.itemView.setOnClickListener {
            onItemListener.onItemClick(position, daysOfMonth[position])
        }
    }

    override fun getItemCount(): Int = daysOfMonth.size
    fun onItemClick(adapterPosition: Int, toString: String) {

    }

    interface OnItemListener {
        fun onItemClick(position: Int, dayText: String)
    }
}
