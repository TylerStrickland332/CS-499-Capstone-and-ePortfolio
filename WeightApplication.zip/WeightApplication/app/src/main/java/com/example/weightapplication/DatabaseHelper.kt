package com.example.weightapplication

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper


class DatabaseHelper(private val context: Context):
    SQLiteOpenHelper(context, DATABASE_NAME,null, DATABASE_VERSION){

    companion object{
        private const val DATABASE_NAME = "UserDatabase.db"
        private const val DATABASE_VERSION = 1
        private const val TABLE_NAME = "data"
        private const val COLUMN_ID = "id"
        private const val COLUMN_USERNAME = "username"
        private const val COLUMN_PASSWORD = "password"
        private const val USER_ID = 0
    }

    override fun onCreate(db: SQLiteDatabase?) {
        val createTableQuery = ("CREATE TABLE $TABLE_NAME (" +
                "$COLUMN_ID INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "$COLUMN_USERNAME TEXT, " +
                "$COLUMN_PASSWORD TEXT)")
        db?.execSQL(createTableQuery)
    }

    override fun onUpgrade(db: SQLiteDatabase?, oldVersion: Int, newVersion: Int) {
        val dropTableQuery = "DROP TABLE IF EXISTS $TABLE_NAME"
        db?.execSQL(dropTableQuery)
        onCreate(db)
    }

    fun insertUser(username: String, password: String, USER_ID: Int): Long {
        val values = ContentValues().apply {
            put(COLUMN_PASSWORD, password)
            put(COLUMN_USERNAME, username)
        }
        val db = writableDatabase
        return db.insert(TABLE_NAME, null, values)
    }

    fun readUserID(userID: String): Boolean {
        val db = readableDatabase
        val selection = "$USER_ID = ?"
        var selectionArgs = arrayOf(userID)

        val cursor = db.query(TABLE_NAME, null, selection, selectionArgs, null, null, null)

        val userIDExists = cursor.count > 0
        cursor.close()
        return userIDExists
    }

    fun readUser(username: String, password: String): Boolean {
        val db = readableDatabase
        val selection = "$COLUMN_USERNAME = ? AND $COLUMN_PASSWORD = ?"
        val selectionArgs = arrayOf(username, password)

        val cursor = db.query(TABLE_NAME, null, selection, selectionArgs, null, null, null)

        val userExists = cursor.count > 0
        cursor.close()
        return userExists
    }
    fun readUserID(username: String, password: String): String {
        val db = readableDatabase
        val selection = "$COLUMN_USERNAME = ? AND $COLUMN_PASSWORD = ?"
        val selectionArgs = arrayOf(username, password)

        val cursor = db.query(USER_ID.toString(), null, selection, selectionArgs, null, null, null)

        if (cursor.moveToFirst()) {
            // Get the index of the USER_ID column
            val userIdIndex = cursor.getColumnIndex("USER_ID") // Replace "USER_ID" with the actual column name if needed

            // Retrieve the value
            var userId = cursor.getString(userIdIndex) // Use getInt, getLong, etc., based on the data type

            // Do something with the userId
            println("User ID: $userId")
            return userId
        } else {
            println("No results found.")
            return ""
        }
        cursor.close()

    }

}