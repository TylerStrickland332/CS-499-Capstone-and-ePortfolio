package com.example.weightapplication

import LoginActivity
import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class GraphHelper(private val context: Context) :
    SQLiteOpenHelper(context, DATABASE_NAME, null, DATABASE_VERSION) {

    companion object {
        private const val DATABASE_NAME = "WeightDatabase.db"
        private const val DATABASE_VERSION = 1
        private const val COLUMN_ID = "id"
        private const val COLUMN_WEIGHT = "weight"
        private const val COLUMN_DATE = "date"
        private lateinit var loginActivity: LoginActivity
        private var USER_NAME = loginActivity.loginUsername
        private var PASSWORD = loginActivity.loginPassword
        var userID = loginActivity.getUserID(USER_NAME, PASSWORD)
        private val TABLE_NAME = "WeightToTime$userID"
    }

    override fun onCreate(db: SQLiteDatabase?) {

        val createTableQuery = ("CREATE TABLE $TABLE_NAME(" +
                "$COLUMN_ID INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "$COLUMN_WEIGHT TEXT, " +
                "$COLUMN_DATE TEXT)")
        db?.execSQL(createTableQuery)
    }

    override fun onUpgrade(db: SQLiteDatabase?, oldVersion: Int, newVersion: Int) {
        val dropTableQuery = "DROP TABLE IF EXISTS $TABLE_NAME"
        db?.execSQL(dropTableQuery)
        onCreate(db)
    }

    fun insertWeight(weight: String, date: String): Long {
        val values = ContentValues().apply {
            put(COLUMN_WEIGHT, weight)
            put(COLUMN_DATE, date)
        }
        val db = writableDatabase
        return db.insert(TABLE_NAME, null, values)
    }
    fun readDate(date: String): Boolean {
        val db = readableDatabase
        val selection = "${GraphHelper.COLUMN_DATE} = ?"
        val selectionArgs = arrayOf(date)
        val cursor = db.query(TABLE_NAME, null, selection, selectionArgs, null, null, null)

        val dateExists = cursor.count > 0
        cursor.close()
        return dateExists
    }
}