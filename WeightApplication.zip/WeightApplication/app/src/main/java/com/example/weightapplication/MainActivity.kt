import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.CalendarView
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.weightapplication.CalendarAdapter
import com.example.weightapplication.GraphHelper
import com.example.weightapplication.R
import com.example.weightapplication.databinding.ActivityMainBinding
import java.text.SimpleDateFormat
import java.time.LocalDate
import java.time.YearMonth
import java.time.format.DateTimeFormatter
import java.util.*

class MainActivity : AppCompatActivity(), CalendarAdapter.OnItemListener{

    private lateinit var graphHelper: GraphHelper
    private lateinit var weight: String
    private lateinit var date: String
    private lateinit var binding: ActivityMainBinding
    private lateinit var monthYearText: TextView
    private lateinit var calendarRecyclerView: RecyclerView
    private lateinit var selectedDate: LocalDate

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(R.layout.activity_main)
        initWidgets()
        selectedDate = LocalDate.now()

        graphHelper = GraphHelper(this)

        val weightEditText = findViewById<EditText>(R.id.insertWeight)

        val weightButton = findViewById<Button>(R.id.addWeight)
        val deleteButton = findViewById<Button>(R.id.deleteButton)

        weightButton.setOnClickListener {

            weight = weightEditText.text.toString()
            // Ensure date has been initialized before proceeding
            if (::selectedDate.isInitialized) {
                // Date is initialized, you can proceed with adding weight and date to the database
                // Call a function to add weight and date to the database
                addWeightAndDate(weight, date)
            } else {
                // Date is not initialized, handle this case as needed
                Toast.makeText(this, "Please select a date", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun formatDate(year: Int, month: Int, dayOfMonth: Int): String {
        val cal = Calendar.getInstance()
        cal.set(year, month, dayOfMonth)
        val dateFormat = SimpleDateFormat("MM-dd-yyyy", Locale.getDefault())
        return dateFormat.format(cal.time)
    }

    private fun addWeightAndDate(weight: String, date: String) {

    }

    private fun initWidgets() {
        calendarRecyclerView = findViewById(R.id.calendarRecyclerView)
        monthYearText = findViewById(R.id.MonthYearTV)
    }

    private fun setMonthView(){
        monthYearText.setText(monthYearFromDate(selectedDate))
        var daysInMonth : MutableList<String> = daysInMonthArray (selectedDate)

        val calendarAdapter: CalendarAdapter = CalendarAdapter(daysInMonth, this)
        val layoutManager: RecyclerView.LayoutManager = GridLayoutManager(this, 7)
        calendarRecyclerView.setLayoutManager(layoutManager)
        calendarRecyclerView.setAdapter(calendarAdapter)

    }

    private fun daysInMonthArray(date:LocalDate): MutableList<String> {
        var daysInMonthArray: MutableList<String> = ArrayList()
        var yearMonth: YearMonth = YearMonth.from(date)

        var daysInMonth = yearMonth.lengthOfMonth()

        var firstOfMonth: LocalDate = selectedDate.withDayOfMonth(1)
        var dayOfWeek = firstOfMonth.getDayOfWeek().getValue()

        for (i in 1..42){
            if(i <= dayOfWeek || i > daysInMonth + dayOfWeek){
                daysInMonthArray.add("")
            }
            else{
                daysInMonthArray.add((i - dayOfWeek).toString())
            }
        }
        return daysInMonthArray
    }

    private fun monthYearFromDate(date:LocalDate): String? {
        var formatter = DateTimeFormatter.ofPattern("MMMM yyyy")
        return date.format(formatter);
    }

    override fun onItemClick(position: Int, dayText: String) {
        if(dayText.equals("")){
            val message = "Selected Date " + dayText + " " + monthYearFromDate(selectedDate)
    }

    fun previousMonthAction(view: View){
        var selectedDate = selectedDate.minusMonths(1)
        setMonthView()
    }

    fun nextMonthAction(view:View){
        var selectedDate = selectedDate.plusMonths(1)
        setMonthView()
    }
} }