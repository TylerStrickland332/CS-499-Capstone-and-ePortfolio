package com.example.weightapplication

import LoginActivity
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import com.example.weightapplication.databinding.ActivitySignupBinding

class SignupActivity : AppCompatActivity() {

    private lateinit var binding: ActivitySignupBinding
    private lateinit var databaseHelper: DatabaseHelper
    private lateinit var signupUsername: String
    private lateinit var signupPassword: String
    private var userId = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySignupBinding.inflate(layoutInflater)
        setContentView(R.layout.activity_signup)

        databaseHelper = DatabaseHelper(this)

        setContentView(R.layout.activity_signup)

        val signupUsernameEditText = findViewById<EditText>(R.id.SignupUsername)
        val signupPasswordEditText = findViewById<EditText>(R.id.SignupPassword)
        val SignupButton = findViewById<Button>(R.id.SignupButton)

        SignupButton.setOnClickListener{
            signupUsername = signupUsernameEditText.text.toString()
            signupPassword = signupPasswordEditText.text.toString()
            signupDatabase(signupUsername, signupPassword)
        }

        val LoginRedirect = findViewById<TextView>(R.id.LoginRedirect)
        LoginRedirect.setOnClickListener{
            val intent = Intent(this, LoginActivity::class.java)
            startActivity(intent)
        }

    }

    private fun signupDatabase(username: String, password: String) {
        val passLength = (password.length)
        val specChars = (password.contains("=") || password.contains("@") || password.contains("{") || password.contains("}"))
        val alreadyRegistered = databaseHelper.readUser(username, password)
        if (alreadyRegistered) {
            Toast.makeText(this, "There is already an account with this username, please log in", Toast.LENGTH_SHORT).show()
        } else if (passLength >= 21 || passLength <= 5) {
            Toast.makeText(this, "Your password is too short/long (6 to 20 characters)", Toast.LENGTH_SHORT).show()
        }else if (specChars) {
            Toast.makeText(this, "Password cannot contain the following: =, @, {, }", Toast.LENGTH_SHORT).show()
        }else {
            var userIdString = userId.toString()
            while(databaseHelper.readUserID(userIdString)) {
                userId + 1
                userIdString = userId.toString()
            }
            val insertedRowId = databaseHelper.insertUser(username, password, userId)
            Toast.makeText(this, "Signup Successful", Toast.LENGTH_SHORT).show()
            val intent = Intent(this, LoginActivity::class.java)
            startActivity(intent)
        } }
}
